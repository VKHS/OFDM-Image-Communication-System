# Model library

All 42 supplied Simulink `.slx` or legacy `.mdl` models are indexed in `MODEL_INVENTORY.csv`. Folders are organized by function: reference-vector FFT, serial FFT, OFDM framing and early prototypes. Identifying creator/last-modifier fields in editable SLX metadata were replaced with the neutral string `OFDM Project` where present; functional block XML was not rewritten. Other model package data and parameter settings are preserved. Model filenames in generic prototypes were made unique with neutral identifiers.

The models were archived with multiple MATLAB releases and may require Simulink plus communications and signal-processing toolboxes. Run a source-specific setup script from `code/legacy_matlab` and ensure necessary image assets are on the MATLAB path. The package does not certify all historical models as executable: several are preliminary or contain obsolete third-party blocks. See the master report for actual numerical assumptions and model limitations.
